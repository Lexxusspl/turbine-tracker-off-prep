import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useState } from "react";
import { cn } from "@/lib/utils";

const turbines = [
  1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 16, 17, 18, 20,
  21, 22, 23, 24, 27, 28, 30, 31, 32, 33, 34, 35, 39, 40,
  41, 42, 44, 45, "46b", 56, 61, 62, 63
];

const components = [
  "bottom", "mid1", "mid2", "mid3", "mid4", "top",
  "nacella", "hub", "blade1", "blade2", "blade3", "cooler"
];

const tasks = ["rozładunek", "preparacja", "mycie"];

export default function TurbineTracker() {
  const [progress, setProgress] = useState({});

  const toggleStatus = (turbine, component, task) => {
    const key = `${turbine}-${component}-${task}`;
    setProgress((prev) => ({
      ...prev,
      [key]: prev[key] === "done" ? null : "done"
    }));
  };

  const totalTasks = turbines.length * (components.length * 2 + 1);
  const completedTasks = Object.values(progress).filter((val) => val === "done").length;

  return (
    <Tabs defaultValue="tracker" className="p-4">
      <TabsList className="mb-6">
        <TabsTrigger value="tracker">Progres</TabsTrigger>
        <TabsTrigger value="summary">Podsumowanie</TabsTrigger>
      </TabsList>

      <TabsContent value="tracker">
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {turbines.map((turbine) => (
            <Card key={turbine} className="rounded-2xl shadow-lg p-4 border border-gray-200">
              <CardContent>
                <h2 className="text-2xl font-semibold mb-4 text-blue-800">Turbina {turbine}</h2>
                {components.map((component) => (
                  <div key={component} className="mb-3">
                    <div className="text-sm font-medium text-gray-700 capitalize mb-1">
                      {component}
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {tasks.map((task) => {
                        if (task === "mycie" && component === "cooler") return null;
                        const key = `${turbine}-${component}-${task}`;
                        return (
                          <Button
                            key={key}
                            variant="outline"
                            className={cn(
                              "text-xs px-3 py-1 rounded-full transition-all",
                              progress[key] === "done"
                                ? "bg-green-500 text-white hover:bg-green-600"
                                : "bg-white border-gray-300 hover:bg-gray-100"
                            )}
                            onClick={() => toggleStatus(turbine, component, task)}
                          >
                            {task}
                          </Button>
                        );
                      })}
                      {component === "nacella" && (
                        <Button
                          variant="outline"
                          className={cn(
                            "text-xs px-3 py-1 rounded-full transition-all",
                            progress[`${turbine}-${component}-cooler-install`] === "done"
                              ? "bg-green-500 text-white hover:bg-green-600"
                              : "bg-white border-gray-300 hover:bg-gray-100"
                          )}
                          onClick={() =>
                            toggleStatus(turbine, component, "cooler-install")
                          }
                        >
                          instalacja coolera
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          ))}
        </div>
      </TabsContent>

      <TabsContent value="summary">
        <div className="text-center py-10">
          <h2 className="text-3xl font-bold mb-4 text-green-700">Podsumowanie postępu</h2>
          <p className="text-lg">Ukończono {completedTasks} z {totalTasks} zadań</p>
          <p className="text-xl font-semibold text-blue-600 mt-2">
            {Math.round((completedTasks / totalTasks) * 100)}% wykonane
          </p>
        </div>
      </TabsContent>
    </Tabs>
  );
}
