import TurbineTracker from "@/components/ui/turbine-tracker";

export default function Page() {
  return <TurbineTracker />;
}
